<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <title>PEMBELIAN</title>
</head>
<body>
    <body style="background: black">
    <div class="container mt-5">
        <div class="row">
            <div class="col-md-12">
               <div class="card">
                  <div class="card-heeader">
                    <h3 class="card-title position-relative">Edit Pembelian<h3>
                </div>
                <div class="card-body">
                    <form action="/update"method="post">
                        <div class="mb-3">
                        <input type="hidden" name="id" value="{{ $pembelian->id}}">
                        <label for="exampleFormControlInput" class="form-label">Ayam</label>
                        <input type="text" class="from-control" name="ayam" id="exampleFormControlInput1" value="{{ $pembelian->ayam }}" placeholder="ayam">
                   </div>
                   <div class="mb-3">
                        <input type="hidden" name="id" value="{{ $pembelian->id}}">
                        <label for="exampleFormControlInput" class="form-label">ayam_goreng</label>
                        <input type="text" class="from-control" name="ayam_goreng" id="exampleFormControlInput1" value="{{ $pembelian->ayam_goreng }}" placeholder="ayam_goreng">
                   </div>
                   <div class="mb-3">
                        <input type="hidden" name="id" value="{{ $pembelian->id}}">
                        <label for="exampleFormControlInput" class="form-label">ayam_panggang</label>
                        <input type="text" class="from-control" name="ayam_panggang" id="exampleFormControlInput1" value="{{ $pembelian->ayam_panggang }}" placeholder="ayam">
                   </div>
                   <div class="mb-3">
                        <input type="hidden" name="id" value="{{ $pembelian->id}}">
                        <label for="exampleFormControlInput" class="form-label">total_bayar</label>
                        <input type="text" class="from-control" name="total_harga" id="exampleFormControlInput1" value="{{ $pembelian->total_harga }}" placeholder="total_harga">
                   </div>
                   <button type="sumbit" class="btn btn-primary">Update</button>
                   </form>
                  </div>
                     </div>
                    </div>
                 </div>
               </div>
            </body>
           </body>
             </html>