<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Pembelian;

class WebController extends Controller
{
    public function tampilan()
    {
        $data['pembelian'] = Pembelian::get();
        return view('dashbord', $data);
       
    }
    //make create insert data validate to database

    public function create()
    {
        return view('add');
    }

    public function store(Request $request)
    {
        $this->validate($request, [
            'id' => 'required',
            'ayam' => 'required',
            'ayam_goreng' => 'required',
            'ayam_panggang' => 'required',
            'total_harga' => 'required',
        ]);

        $pembelian = Pembelian::create([
            'id' => $request->id,
            'ayam' => $request->ayam,
            'ayam_goreng' => $request->ayam_goreng,
            'ayam_panggang' => $request->ayam_panggang,
            'total_harga' => $request->total_harga,
        ]);

        if ($pembelian) {
            return redirect('/dashbord')->with('success','Data berhasil ditambahkan');
        }else{
            return redirect('/dashbord')->with('error','Data gagal ditambahkan');
        
        }
    }
    public function edit($id)
    {
        $data['pembelian'] = pembelian::find($id);

        return view('edit', $data);
    }
    public function update(Request $request)
    {
        $update = Pembelian::where('id',$request->id)->update([
            'ayam' => $request->ayam,
            'ayam_goreng' => $request->ayam_goreng,
            'ayam_panggang' => $request->ayam_panggang,
            'total_harga' => $request->total_harga,
        ]);

        if($update) return redirect('/dashbord');
        else return 'gagal update data';
    }


    // make method destroy data from database
    public function destroy($id)
    {
        $delete = Pembelian::destroy($id);

        if($delete) return redirect('/dashbord');
        else return 'gagal delete data';
    }
  
}
